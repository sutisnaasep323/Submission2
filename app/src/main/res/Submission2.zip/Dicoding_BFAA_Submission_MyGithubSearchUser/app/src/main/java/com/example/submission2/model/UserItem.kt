package com.example.submission2.model

data class UserItem(
    var login: String,
    var url: String,
    var avatar_url: String
)