package com.example.submission2.model

data class UserResponse(
    val items: ArrayList<UserItem>
)
